<!-- footer.php -->

<footer>
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> My Web Application</p>
        <!-- Add any additional footer content or links here -->
    </div>
</footer>
